//>>built
define("epi-addon-xforms/layers/widgets",["epi-addon-xforms/Module","epi-addon-xforms/XFormEditor"],1);